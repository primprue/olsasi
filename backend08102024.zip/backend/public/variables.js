
var dirpresupdocumento = '/home/sandra/Documentos/OLSAFrecuentes/PresupSistema/';
var dirotdocumento = '/home/sandra/Documentos/OLSAFrecuentes/OrdenTrabajo/';
// var caminoynombrearch = ' /home/sandra/SistOLSA/OlsaSG/build/static/media/basics.pdf';
// var caminoynombrearch = '/home/sandra/SistOLSA/olsasi/public/';
// var caminoynombrearch = '/home/sandra/OLSASI/OlsaSI/dist/';
var caminoynombrearch = '/home/sandra/SistOLSA/olsasi/dist/';
module.exports = {
    dirpresupdocumento,
    dirotdocumento,
    caminoynombrearch
}

