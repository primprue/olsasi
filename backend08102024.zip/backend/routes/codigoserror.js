// if (err.status === 409) => 1062 => cuando se da de alta un código existente
// if (err.status === 410) => 1406 => el campo  alfanumérico más grande de lo que corresponde 
// if (err.status === 412) => 1264 => el campo numérico más grande de lo que corresponde
// if (err.status === 411) => 1451 => Código  Usado no se puede borrar 
// if (err.status === 413) => 1366 => Faltan datos para ingresar información en tabla
// if (err.status === 414) => 1054 => Faltan datos para leer información en tabla

