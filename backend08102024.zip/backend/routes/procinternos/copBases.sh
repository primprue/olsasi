ls /home/sandra > /home/sandra/SistOLSA/OlsaSG/backend/routes/procinternos/dd
